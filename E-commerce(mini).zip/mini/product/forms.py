from django import forms
from.models import Productmodel
from django .contrib.auth.forms import UserCreationForm
from  django.contrib.auth.models import User


class Regform(UserCreationForm):
    username=forms.CharField(widget=forms.TextInput(
        attrs={'palceholder':' Your Username ',
               'class':'form-control'
               }
    ))
    first_name=forms.CharField(widget=forms.TextInput(
        attrs={'palceholder':' Your first Name ',
               'class':'form-control'
               }
    ))
    last_name=forms.CharField(widget=forms.TextInput(
        attrs={'palceholder':' Your last Name ',
               'class':'form-control'
               }
    ))
    email=forms.CharField(widget=forms.EmailInput(
        attrs={'palceholder':' Your Email ',
               'class':'form-control'
               }
    ))
    password1=forms.CharField(widget=forms.PasswordInput(
        attrs={'palceholder':' Password',
               'class':'form-control'
               }
    ))
    password2=forms.CharField(widget=forms.PasswordInput(
        attrs={'palceholder':'Confirm Password',
               'class':'form-control'
               }
    ))
    
    class Meta:
        model=User
        fields=['username','first_name','last_name','email']
       

class Productform(forms.ModelForm):
    class Meta:
        model=Productmodel
        fields=['product_name','brand_name','product_type','user_type','price','img']