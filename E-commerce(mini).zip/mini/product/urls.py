from django.urls import path
from.import views
from django.conf.urls.static import static
from django.conf import settings


urlpatterns=[
    path('home',views.home ,name='home'),
    path('add',views.Addproduct,name="add"),
    path('created',views.added ),
    path('detail/<int:id>',views.details, name='details'),
    path('edit/<int:id>',views.editproduct ,name='edit'),
    path('delete/<int:id>/', views.delet, name='delete'),
    path('login',views.loginuser,name="login"),
    path('logout',views.logoutuser, name="logout"),
    path('register',views.register, name="register"),
    path('brand',views.brandd ,name='brand'),
    path('type',views.typee ,name='type'),


]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)