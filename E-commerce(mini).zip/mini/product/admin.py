from django.contrib import admin
from.models import Productmodel,Category,Category2
# Register your models here.
admin.site.register(Productmodel)
admin.site.register(Category)
admin.site.register(Category2)