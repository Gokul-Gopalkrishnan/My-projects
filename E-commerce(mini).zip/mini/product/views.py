from django.shortcuts import render,redirect
from.forms import *
from.models import *
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages

# Create your views here.


def home(request): #home page
    product=Productmodel.objects.all()
    return render(request,'home.html',{'product':product})

def brandd(request): #home page
    product=Productmodel.objects.all()
    return render(request,'brand.html',{'product':product})

def typee(request): #home page
    product=Productmodel.objects.all()
    return render(request,'type.html',{'product':product})

def loginuser(request):       #login 
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)
        if user:
            login(request,user)
            messages.success(request,'User successfully logged in')
            return redirect(home)
        else:
            messages.error(request,'Somthing went wrong user not loggedd in')
            return redirect(home)
    return render(request,'login.html')
    
def logoutuser(request):                                      #logout
    if request.method=='POST':
        logout(request)
        messages.success(request,'logged out')
        return redirect(home)   
    return render(request,'logout.html')

def register(request):  #validation
    if request.method=='POST':
        form=Regform(request.POST)
        if form.is_valid():
            form.save()
            return redirect(home)
    else:
        form=Regform()
    return render(request,'register.html',{'form':form})
 
def Addproduct(request): # product adding
    if request.method=='POST':
        product=Productform(request.POST, request.FILES)
        if product.is_valid():
            product1=Productmodel(
                product_name=product.cleaned_data['product_name'],
                brand_name=product.cleaned_data['brand_name'],
                price=product.cleaned_data['price'],
                user_type=product.cleaned_data['user_type'],
                img=product.cleaned_data['img'],
            )
            product1.save()
            return redirect(added)
    else:
        product=Productform()
        return render(request,'addproduct.html',{'form':product})   
    

def added(request): #message
    return render(request,'added.html')

def details(request,id):  # for getting details
    product=Productmodel.objects.get(id=id)
    return render(request,'detail.html',{'product':product})  

def editproduct(request, id): # edit product
    product = Productmodel.objects.get(id=id)
    if request.method == "POST":
        product_form = Productform(request.POST, request.FILES, instance=product)
        if product_form.is_valid():
            product_form.save()
            return redirect(added)
    else:
        product_form = Productform(instance=product)
    return render(request, 'edit.html', {'product': product_form})

def delet(request,id):  #product delete
    pro=Productmodel.objects.get(id=id)
    if request.method=="POST":
        pro.delete()
        return redirect(home)
    return render (request,'delete.html',{'pro':pro})


 