from django.db import models
from  django.contrib.auth.models import User
# Create your models here.

class Category(models.Model):
    brand_name=models.CharField(max_length=200,null=True) 
    def __str__(self):
        return self.brand_name
class Category2(models.Model):
    product_type=models.CharField(max_length=200,null=True)
    def __str__(self): 
        return self.product_type 

class Productmodel(models.Model):
    product_name=models.CharField(max_length=200)
    brand_name=models.ForeignKey(Category,on_delete=models.CASCADE,null=True)
    product_type=models.ManyToManyField(Category2)
    user_type=models.CharField(max_length=100,null=True,blank=True)
    price=models.IntegerField()
    img=models.ImageField(upload_to='product_image',null=True,blank=True)


class profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    age=models.IntegerField()
    email=models.EmailField()
    def __str__(self):
        return self.user.username
