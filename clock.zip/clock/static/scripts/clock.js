let hr = document.getElementById("hour");
let min = document.getElementById("mini");
let sec = document.getElementById("seco");

function displaytime() {
    // getting hour, minute, seconds
    let date = new Date();

    let hh = date.getHours();
    let m = date.getMinutes();
    let s = date.getSeconds();

    // rotation
    let hourrotation = 30 * hh + (m / 2);
    let minrotation = 6 * m;
    let secrotation = 6 * s;

    hr.style.transform = `rotate(${hourrotation}deg)`;
    min.style.transform = `rotate(${minrotation}deg)`;       
    sec.style.transform = `rotate(${secrotation}deg)`;
}

setInterval(displaytime, 1000);
