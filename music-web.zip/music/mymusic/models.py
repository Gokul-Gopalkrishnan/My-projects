from django.db import models
from  django.contrib.auth.models import User
# Create your models here.

class Artist(models.Model):
    artist_name=models.CharField(max_length=100)
    def __str__(self):
        return self.artist_name
  
class Gener(models.Model):
    gener=models.CharField(max_length=100)    
    def __str__(self):
        return self.gener  
     
class Source(models.Model):
    source=models.CharField(max_length=100)    
    def __str__(self):
        return self.source
         
class Language(models.Model):
    language=models.CharField(max_length=100)    
    def __str__(self):
        return self.language
          

class Songmodel(models.Model):
    tittle=models.CharField(max_length=100,null=True,blank=True)
    img=models.ImageField(upload_to='music_img',null=True,blank=True)
    artist=models.ForeignKey(Artist,on_delete=models.CASCADE,null=True)
    source=models.ForeignKey(Source,on_delete=models.CASCADE,null=True)
    gener=models.ForeignKey(Gener,on_delete=models.CASCADE,null=True)
    language=models.ForeignKey(Language,on_delete=models.CASCADE,null=True)
    audio=models.FileField(upload_to='songs',null=True,)
    duration = models.DurationField(null=True,blank=True)

    def __str__(self):
        return self.tittle
          


class Profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    email=models.EmailField()
    def __str__(self):
        return self.user.username