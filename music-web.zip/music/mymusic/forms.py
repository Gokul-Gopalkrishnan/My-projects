from django import forms
from.models import *
from django .contrib.auth.forms import UserCreationForm
from  django.contrib.auth.models import User




class Form_models(forms.ModelForm):
    class Meta:
        model=Songmodel
        fields=['tittle','artist','source','gener','language','audio','img']

class Regform(UserCreationForm):
    username=forms.CharField(widget=forms.TextInput(
        attrs={'placeholder':' Your Username ',
               'class':'reg'
               }
    ))
    first_name=forms.CharField(widget=forms.TextInput(
        attrs={'placeholder':' Your first Name ',
               'class':'reg'
               }
    ))
    last_name=forms.CharField(widget=forms.TextInput(
        attrs={'placeholder':'Your last Name',
               'class':'reg'
               }
    ))
    email=forms.CharField(widget=forms.EmailInput(
        attrs={
               'class':'reg','placeholder':'Your Email '
               }
    ))
    password1=forms.CharField(widget=forms.PasswordInput(
        attrs={
               'class':'reg2','placeholder':'Password',
               }      
    ),label="Password"  )


    password2=forms.CharField(widget=forms.PasswordInput(
        attrs={
               'class':'reg3','placeholder':'Confirm Password'
               }       
    ),label="Confirm Password")
    
    class Meta:
        model=User
        fields=['username','first_name','last_name','email',]
      
class Songform(forms.ModelForm):
    class Meta:
        model=Songmodel
        fields=['tittle','img','artist','source','gener','language','audio','duration']