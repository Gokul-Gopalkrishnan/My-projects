from django.contrib import admin
from.models import*
# Register your models here.
admin.site.register(Songmodel)
admin.site.register(Artist)
admin.site.register(Gener)
admin.site.register(Language)
admin.site.register(Profile)
admin.site.register(Source)