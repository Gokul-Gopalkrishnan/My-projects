from rest_framework import serializers
from.models import Songmodel


class Songserializers(serializers.ModelSerializer):
    class Meta:
        model=Songmodel
        fields='__all__'
