from django.shortcuts import render,redirect
from.forms import *
from.models import *
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from rest_framework.response import Response
from rest_framework.decorators import api_view
from.serializers import Songserializers



def home(request):
    Song=Songmodel.objects.all()
    return render(request,'home.html',{'songs':Song})

def register(request):  #validation
    if request.method=='POST':
        form=Regform(request.POST)
        if form.is_valid():
            form.save()
            return redirect(loginuser)
    else:
        form=Regform()
    return render(request,'register.html',{'form':form})
 
def loginuser(request):       #login 
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)
        if user:
            login(request,user)
            messages.success(request,'User successfully logged in')
            return redirect(home)
        else:
            messages.error(request,'Somthing went wrong user not loggedd in')
            return redirect(home)
    return render(request,'login.html')

def logoutuser(request):          #logout
    if request.method=='POST':
        logout(request)
        messages.success(request,'logged out')
        return redirect(home)   
    return render(request,'logout.html')


def profile(request):
    user = request.user
    print(f"User: {user}")  # Add this line for debugging

    if request.user.is_authenticated:
        try:
            profile = Profile.objects.get(user=user)
            print(f"Profile: {profile}")  
            return render(request, 'profile.html', {'profile': profile})
        except Profile.DoesNotExist:
            messages.error(request, 'Profile does not exist for this user.')
            print("Profile does not exist for this user.")  # Add this line for debugging
    else:
        messages.error(request, 'User is not authenticated.')
    return redirect(noprofile)

def noprofile(request):
    return render(request,'nouser.html')

@api_view(['GET'])     #api end point for song list
def songslist(request):
    songs = Songmodel.objects.all()
    serializer = Songserializers(songs, many=True)
    data = serializer.data
    return Response(data)

def addsong(request):
    if request.method=="POST":
        songs=Songform(request.POST,request.FILES)
        if songs.is_valid():
            song1=Songmodel(
                tittle=songs.cleaned_data['tittle'],
                img=songs.cleaned_data['img'],
                artist =songs.cleaned_data['artist'],
                source=songs.cleaned_data['source'],
                gener=songs.cleaned_data['gener'],
                language=songs.cleaned_data['language'],
                audio=songs.cleaned_data['audio'],
                duration=songs.cleaned_data['duration'], 
            )
            song1.save()
            return redirect(added)
    else:
        songs=Songform()
        return render(request,'addsong.html',{'forms':songs})    

def added(request): #message
    return render(request,'added.html')

def editsong(request,id):
    songs=Songmodel.objects.get(id=id)
    if request.method=='POST':
        song1=Songform(request.POST,request.FILES,instance=songs)
        if song1.is_valid():
            song1.save()
            return redirect(added)
    else:
        song1=Songform(instance=songs)
        return render(request,'editsong.html',  {'songs':song1})    

def delete(request,id):  #product delete
    song=Songmodel.objects.get(id=id)
    if request.method=="POST":
        song.delete()
        return redirect(home)
    return render (request,'delete.html',{'song':song})

def search(request): #search
    search1 = request.GET.get('search')
    if search1:
        sea = Songmodel.objects.filter(tittle__icontains=search1)
        return render(request, 'search.html', {'sea': sea})
    else:
        sea = Songmodel.objects.all()
        return render(request, 'search.html', {'sea': sea})

    
def song_details(request,id):
    song=Songmodel.objects.get(id=id) 
    audio_url=song.audio.url  
    return render (request,'details.html',{'song':song})

def artistt(request): #home page
    artist=Songmodel.objects.all()
    return render(request,'artist.html',{'arti':artist})

def genree(request): #home page
    genre=Songmodel.objects.all()
    return render(request,'genre.html',{'genre':genre})