from django.urls import path
from.import views
from django.conf.urls.static import static
from django.conf import settings  


urlpatterns=[
    path('home',views.home,name='home'),
    path('register',views.register, name="register"),
    path('login',views.loginuser,name="login"),
    path('logout',views.logoutuser, name="logout"),
    path('profile',views.profile ,name="profile"),
    path('nouser',views.noprofile,name="nouser"),
    path('list',views.songslist,name="lists") ,  
    path('details/<int:id>',views.song_details,name='details'),
    path('search',views.search,name="search"),
    path('add',views.addsong,name="addsong"),
    path('added',views.added),
    path('edit/<int:id>',views.editsong, name='edit'),
    path('delete/<int:id>/', views.delete, name='delete'),
    path('artist',views.artistt ,name='artist'),
    path('genre',views.genree ,name='genre'),
   
]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)